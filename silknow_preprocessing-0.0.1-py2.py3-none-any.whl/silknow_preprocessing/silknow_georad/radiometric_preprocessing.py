#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, imageio
import numpy as np
import tensorflow as tf

def normalize_image(data_path_name,
                    data_file_name, 
                    result_path_name,
                    result_file_name):
#    
    r"""Shifts and scales the gray values.
    
    The image's pixel values will be shifted and scaled so that the result
    image will have among all three channels a mean value of zero and a
    standard deviation of one.
    
    **Attention**\: Due to the conversion of the normalized result image to the JPEG
    format, the gray values are sclaed to the range [0; 255]. Thus, the saved
    image does not have any longer a mean value of zero and a standard
    deviation of one. Use ``Radiometric_Preprocessing.normalize_image_array()``
    to obtain the normalized result image!    
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be normalized. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the normalized image.
        :result_file_name (*string*)\::
            The name of the normalized image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.per_image_standardization(input_plh)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
    
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)
    

def normalize_image_array(input_array):
#    
    r"""Shifts and scales the gray values.
    
    The image's pixel values will be shifted and scaled so that the result
    image will have among all three channels a mean value of zero and a
    standard deviation of one.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be normalized.
            It has the shape height x width x 3.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the normalized 3-channel image.
            It has the shape height x width x 3 and floats as gray values with
            a mean value of zero and a standard deviation of one.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.per_image_standardization(input_plh)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def adjust_image_brightness(data_path_name,
                            data_file_name, 
                            result_path_name,
                            result_file_name,
                            delta):
    r"""Adjusts the image brightness.
    
    The image brightness will be adjusted for each image channel independently.
    This is achieved by adding a value delta to the gray values of all three
    channels. The resulting values are:
        
        g_channel_1' = g_channel_1 + delta
        
        g_channel_2' = g_channel_2 + delta
        
        g_channel_3' = g_channel_3 + delta
    
    **Attention**\: Due to the conversion of the result image to the JPEG format,
    the gray values are sclaed to integers in the range [0; 255]. Use
    ``Radiometric_Preprocessing.adjust_image_brightness_array()`` to avoid this
    kind of scaling!
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be adjusted. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the adjusted image.
        :result_file_name (*string*)\::
            The name of the adjusted image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
        :delta (*float*)\::
            The value to be added to the gray values of all channels. The value
            can be an arbitrary positive or negative float.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_brightness(input_plh, delta)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
    
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def adjust_image_brightness_array(input_array,
                                  delta):
    r"""Adjusts the image brightness.
    
    The image brightness will be adjusted for each image channel independently.
    This is achieved by adding a value delta to the gray values of all three
    channels. The resulting values are:
        
        g_channel_1' = g_channel_1 + delta
        
        g_channel_2' = g_channel_2 + delta
        
        g_channel_3' = g_channel_3 + delta
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be adjusted.
            It has the shape height x width x 3.
        :delta (*float*)\::
            The value to be added to the gray values of all channels. The value
            can be an arbitrary positive or negative float.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the adjusted 3-channel image.
            It has the shape height x width x 3 and floats as gray values. The
            gray values are depending on delta not in the range of [0, 255];
            the output array can have smaller or larger gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_brightness(input_plh, delta)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array
    

def adjust_image_contrast(data_path_name,
                          data_file_name, 
                          result_path_name,
                          result_file_name,
                          factor):
    r"""Adjusts the image contrast.
    
    The image contrast will be adjusted for each of the three image channels
    independently. The output gray value g' is calculated using the original
    channel's gray value g, the mean gray value of the channel "mean(channel)"
    and the given contrast factor "factor" via:
        
        g' = (g - mean(channel)) * factor + mean(channel).
    
    **Attention**\: Due to the conversion of the result image to the JPEG format,
    the gray values are sclaed to integers in the range [0; 255]. Use
    ``Radiometric_Preprocessing.adjust_image_contrast_array()`` to avoid this
    kind of scaling!
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be adjusted. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the adjusted image.
        :result_file_name (*string*)\::
            The name of the adjusted image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
        :factor (*float*)\::
            The contrast factor for adjusting the contrast of each image
            channel. It can be an arbitrary positive or negative float.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_contrast(input_plh, factor)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
    
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def adjust_image_contrast_array(input_array,
                                factor):
    r"""Adjusts the image contrast.
    
    The image contrast will be adjusted for each of the three image channels
    independently. The output gray value g' is calculated using the original
    channel's gray value g, the mean gray value of the channel "mean(channel)"
    and the given contrast factor "factor" via:
        
        g' = (g - mean(channel)) * factor + mean(channel).
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be adjusted.
            It has the shape height x width x 3.
        :factor (*float*)\::
            The contrast factor for adjusting the contrast of each image
            channel. It can be an arbitrary positive or negative float.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the adjusted 3-channel image.
            It has the shape height x width x 3 and floats as gray values. The
            gray values are for | factor | > 1 not in the range of [0, 255];
            the output array have smaller or larger gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_contrast(input_plh, factor)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array}) 
    return output_array
    

def gamma_image_correction(data_path_name,
                           data_file_name, 
                           result_path_name,
                           result_file_name,
                           gamma):
    r"""Performs a gamma correction of the image.
    
    All values of the pixels g of the original image will be changed to new
    values g' via:
        
        g' = g^gamma
    
    **Attention**\: Due to the conversion of the result image to the JPEG format,
    the gray values are sclaed to integers in the range [0; 255]. Use
    ``Radiometric_Preprocessing.gamma_image_correction_array()`` to avoid this
    kind of scaling!
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be corrected. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the corrected image.
        :result_file_name (*string*)\::
            The name of the corrected image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
        :gamma (*float*)\::
            The parameter for the gamma correction. The value has to be larger
            than zero.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_gamma(input_plh, gamma)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
       
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)
    

def gamma_image_correction_array(input_array,
                                 gamma):
    r"""Performs a gamma correction of the image.
    
    All values of the pixels g of the original image will be changed to new
    values g' via:
        
        g' = g^gamma
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be corrected.
            It has the shape height x width x 3.
        :gamma (*float*)\::
            The parameter for the gamma correction. The value has to be larger
            than zero.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the corrected 3-channel image.
            It has the shape height x width x 3 and floats as gray values. The
            gray values are for gamma > 1 not in the range of [0, 255];
            the output array contains larger gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_gamma(input_plh, gamma)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array
    

def adjust_image_hue(data_path_name,
                     data_file_name, 
                     result_path_name,
                     result_file_name,
                     delta):
    r"""Adjusts the hue of the image.
    
    The image will be converted from the RGB color space to the HSV color
    space. Afterwards, the given delta value will be added to the hue channel (H).
    Delta describes a fraction of the full color circle in the HSV color
    space's hue channel. The values of delta have to be in the range [-1, +1]
    so that the maximum rotation of the hue value can be plus or minus one full
    circle. If delta = 0.5, the original hue value H gets an offset of half of
    the color circle resulting in a new hue value H':
        
        H' = H + delta * 2pi
    
    Finally, the image is converted back to the RGB color space.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be adjusted. The image
            has to be an RGB image.
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the adjusted image.
        :result_file_name (*string*)\::
            The name of the adjusted image. The result image is an 
            RGB image with gray values in the range [0; 255].
        :delta (*float*)\::
            The fraction of the full color circle to be added to the hue value
            of each pixel. The value has to be in the range [-1, 1].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_hue(input_plh, delta)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def adjust_image_hue_array(input_array,
                           delta):
    r"""Adjusts the hue of the image.
    
    The image will be converted from the RGB color space to the HSV color
    space. Afterwards, the given delta value will be added to the hue channel (H).
    Delta describes a fraction of the full color circle in the HSV color
    space's hue channel. The values of delta have to be in the range [-1, +1]
    so that the maximum rotation of the hue value can be plus or minus one full
    circle. If delta = 0.5, the original hue value H gets an offset of half of
    the color circle resulting in a new hue value H':
        
        H' = H + delta * 2pi
    
    Finally, the image is converted back to the RGB color space.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be adjusted.
            It has the shape height x width x 3 and has to be an RGB image.
        :delta (*float*)\::
            The fraction of the full color circle to be added to the hue value
            of each pixel. The value has to be in the range [-1, 1].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the adjusted RGB image.
            It has the shape height x width x 3 and has gray values in the
            range of [0; 255].
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_hue(input_plh, delta)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array}) 
    return output_array
    

def adjust_image_saturation(data_path_name,
                            data_file_name, 
                            result_path_name,
                            result_file_name,
                            factor):
    r"""Adjusts the saturation of the image.
    
    The image will be converted from the RGB color space to the HSV color
    space. Afterwards, the saturation (S) of each pixel will be multiplyed by
    the given factor:
        
        S' = S * factor
    
    Finally the image is converted back to the RGB color space.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be adjusted. The image
            has to be an RGB image.
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the adjusted image.
        :result_file_name (*string*)\::
            The name of the adjusted image. The result image is an 
            RGB image with gray values in the range [0; 255].
        :factor (*float*)\::
            The factor for multiplying the saturation of each pixel. The value
            can be an arbitrary positive or negative float.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_saturation(input_plh, factor)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res.astype(np.uint8))


def adjust_image_saturation_array(input_array,
                                  factor):
    r"""Adjusts the saturation of the image.
    
    The image will be converted from the RGB color space to the HSV color
    space. Afterwards, the saturation (S) of each pixel will be multiplyed by
    the given factor:
        
        S' = S * factor
    
    Finally the image is converted back to the RGB color space.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be adjusted.
            It has the shape height x width x 3 and has to be an RGB image.
        :factor (*float*)\::
            The factor for multiplying the saturation of each pixel. The value
            can be an arbitrary positive or negative float.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the adjusted RGB image.
            It has the shape height x width x 3 and has gray values in the
            range of [0; 255].
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.adjust_saturation(input_plh, factor)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})  
    return output_array


def convert_RGB_to_grayscale(data_path_name,
                             data_file_name, 
                             result_path_name,
                             result_file_name):
    r"""Converts an RGB image to a grayscale image.
    
    A given RGB image will be converted to a grayscale image having only one
    channel. The gray values g_gray are estimated out of the RGB values
    (g_R, g_G, g_B) of each pixel via:
    
        g_gray = 0.2989*g_R + 0.5870*g_G + 0.1140*g_B
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be converted. The image
            has to be a 3-channel image in the RGB color space. The gray values
            have to be in the range [0; 255].
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the converted image.
        :result_file_name (*string*)\::
            The name of the converted image. The result image is a 
            3-channel HSV image. The gray values of the saved image are scaled
            to integers in the range [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.rgb_to_grayscale(input_plh)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    res = np.squeeze(res, axis = 2)
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def convert_RGB_to_grayscale_array(input_array):
    r"""Converts an RGB image to a grayscale image.
    
    A given RGB image will be converted to a grayscale image having only one
    channel. The gray values g_gray are estimated out of the RGB values
    (g_R, g_G, g_B) of each pixel via:
    
        g_gray = 0.2989*g_R + 0.5870*g_G + 0.1140*g_B
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be converted.
            It has the shape height x width x 3. The image has to be a in the
            RGB color space with gray values in the range [0; 255].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the converted grayscale image.
            It has the shape height x width x 1 and floats in the range of
            [0; 255] as gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.rgb_to_grayscale(input_plh)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return np.squeeze(output_array, axis = 2)

    
def convert_RGB_to_HSV(data_path_name,
                       data_file_name, 
                       result_path_name,
                       result_file_name):
    r"""Converts an RGB image to HSV color space.
    
    A given image in the RGB color space will be converted to the HSV color
    space. 
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be converted. The image
            has to be a 3-channel image in the RGB color space. The gray values
            have to be in the range [0; 255].
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the converted image.
        :result_file_name (*string*)\::
            The name of the converted image. The result image is a 
            3-channel HSV image. The gray values of the saved image are scaled
            to integers in the range [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.uint8)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.uint8, [None, None, 3])
        # Convert from full range of uint8 to range [0,1] of float32.
        decoded_image_as_float = tf.image.convert_image_dtype(input_plh,
                                                        tf.float32)
        result_plh = tf.image.rgb_to_hsv(decoded_image_as_float)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def convert_RGB_to_HSV_array(input_array):
    r"""Converts an RGB image to HSV color space.
    
    A given image in the RGB color space will be converted to the HSV color
    space. 
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be converted.
            It has the shape height x width x 3. The image has to be a in the
            RGB color space with gray values in the range [0; 255].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the converted RGB image.
            It has the shape height x width x 3 and floats in the range of
            [0; 1] as gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.uint8, [None, None, 3])
        # Convert from full range of uint8 to range [0,1] of float32.
        decoded_image_as_float = tf.image.convert_image_dtype(input_plh,
                                                        tf.float32)
        result_plh = tf.image.rgb_to_hsv(decoded_image_as_float)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def convert_HSV_to_RGB(data_path_name,
                       data_file_name, 
                       result_path_name,
                       result_file_name):
    r"""Converts an image from HSV to an RGB image.
    
    A given image in the HSV color space will be converted to an image in the
    RGB color space. 
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be converted. The image
            has to be a 3-channel image in the HSV color space. The gray values
            have to be in the range [0; 255].
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the converted image.
        :result_file_name (*string*)\::
            The name of the converted image. The result image is a 
            3-channel RGB image. The gray values of the saved image are scaled
            to integers in the range [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.uint8)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.uint8, [None, None, 3])
        # Convert from full range of uint8 to range [0,1] of float32.
        decoded_image_as_float = tf.image.convert_image_dtype(input_plh,
                                                        tf.float32)
        result_plh = tf.image.hsv_to_rgb(decoded_image_as_float)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def convert_HSV_to_RGB_array(input_array):
    r"""Converts an image from HSV to an RGB image.
    
    A given image in the HSV color space will be converted to an image in the
    RGB color space.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be converted.
            It has the shape height x width x 3. The image has to be a in the
            HSV color space with gray values in the range [0; 255].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the converted RGB image.
            It has the shape height x width x 3 and floats in the range of
            [0; 1] as gray values.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.uint8, [None, None, 3])
        # Convert from full range of uint8 to range [0,1] of float32.
        decoded_image_as_float = tf.image.convert_image_dtype(input_plh,
                                                        tf.float32)
        result_plh = tf.image.hsv_to_rgb(decoded_image_as_float)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array
    
    
def convert_grayscale_to_RGB(data_path_name,
                        data_file_name, 
                        result_path_name,
                        result_file_name):
    r"""Converts a grayscale image to an RGB image.
    
    A given grayscale image will be converted to a 3-channel image.
    The resulting RGB image (3-channel image) has the same
    values in each channel, that are exactly the ones from the grayscale image
    (1-channel image).
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be converted. The image
            has to be a 1-channel image. The gray values have to be in the
            range [0; 255].
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the converted image.
        :result_file_name (*string*)\::
            The name of the converted image. The result image is a 
            3-channel RGB image. The gray values of the saved image are scaled
            to integers in the range [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
        
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    img_gray = np.expand_dims(img, axis=2)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 1])
        result_plh = tf.image.grayscale_to_rgb(input_plh)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img_gray})
    
    mi = np.nanmin(res)
    ma = np.nanmax(res)
    res = res.astype("float64")
    res = (res - mi) / (ma - mi) * (np.power(2.0, 8) - 1) + 0.499999999
    res = res.astype(np.uint8)
    imageio.imsave(os.path.join(result_path_name, result_file_name), 
                    res)


def convert_grayscale_to_RGB_array(input_array):
    r"""Converts a grayscale image to an RGB image.
    
    A given grayscale image will be converted to a 3-channel image.
    The resulting RGB image (3-channel image) has the same
    values in each channel, that are exactly the ones from the grayscale image
    (1-channel image).
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be converted.
            It has the shape height x width x 1. The gray values in the
            range [0; 255].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the converted RGB image.
            It has the shape height x width x 3 gray values in the range of
            [0; 255].
    """
    img_gray = np.expand_dims(input_array, axis=2)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 1])
        result_plh = tf.image.grayscale_to_rgb(input_plh)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: img_gray})
    return output_array


