#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, imageio
import numpy as np
import tensorflow as tf
from scipy.misc import imsave

# Geometrical Transformations

# Translate an image
def translate_image_2D(data_path_name,
                       data_file_name, 
                       result_path_name,
                       result_file_name,
                       delta_x,
                       delta_y):
    r"""Translates the image in two dimensions.
    
    The image will be translated by the given height (delta_y) and the given
    width (delta_x). The values for pixels for which no information is
    available in the original image will be set to (0, 0, 0) (black).
    
    If delta_x = 100, the image will be shifted by 100 pixels to the right.
    This results in a black strip of 100 black pixels on the left side and the
    loss of the 100 most right pixels of the original image on the right side. 
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be translated. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the translated image.
        :result_file_name (*string*)\::
            The name of the translated image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :delta_x (*int*)\::
            The number of pixels for the horizontal translation. A
            positive number means a shift to the right. The value should not be
            larger than the original image width.
        :delta_y (*int*)\::
            The number of pixels for the vertical translation. A
            positive number means a shift to the bottom. The value should not
            be larger than the original image height.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.    
    """
    
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.translate(input_plh, [delta_x, delta_y])
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)
    
    #test imageio
    imageio.imwrite(os.path.join(result_path_name, 'imio_' + result_file_name), 
                    res)
    

def translate_image_2D_array(input_array,
                             delta_x,
                             delta_y):
    r"""Translates the image in two dimensions.
    
    The image will be translated by the given height (delta_y) and the given
    width (delta_x). The values for pixels for which no information is
    available in the original image will be set to (0, 0, 0) (black).
    
    If delta_x = 100, the image will be shifted by 100 pixels to the right.
    This results in a black strip of 100 black pixels on the left side and the
    loss of the 100 most right pixels of the original image on the right side. 
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be translated.
            It has the shape height x width x 3.
        :delta_x (*int*)\::
            The number of pixels for the horizontal translation. A
            positive number means a shift to the right. The value should not be
            larger than the original image width.
        :delta_y (*int*)\::
            The number of pixels for the vertical translation. A
            positive number means a shift to the bottom. The value should not
            be larger than the original image height.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the translated 3-channel image.
            It has the shape height x width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.translate(input_plh, [delta_x, delta_y])
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})   
    return output_array
    

def rotate_image_counter_clockwise(data_path_name,
                                   data_file_name, 
                                   result_path_name,
                                   result_file_name,
                                   angle_rad):
    r"""Rotates the image counter clockwise by a given angle.
    
    The given image will be rotated counter-clockwise by the given angle
    in radians (angle_rad). The values for pixels for which no information is
    available in the original image will be set to (0, 0, 0) (black).
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be rotated.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the rotated image.
        :result_file_name (*string*)\::
            The name of the rotated image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :angle_rad (*float*)\::
            The rotation angle in [rad]. The value for angle_rad can be an
            arbitrary positive or negative angle in radians (it does not have
            to be in the interval [-2*pi; +2*pi], modulo 2*pi will be realized
            automatically).
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.rotate(input_plh, angle_rad)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def rotate_image_counter_clockwise_array(input_array,
                                         angle_rad):
    r"""Rotates the image counter clockwise by a given angle.
    
    The given image will be rotated counter-clockwise by the given angle
    in radians (angle_rad). The values for pixels for which no information is
    available in the original image will be set to (0, 0, 0) (black). 
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be rotated.
            It has the shape height x width x 3.
        :angle_rad (*float*)\::
            The rotation angle in [rad]. The value for angle_rad can be an
            arbitrary positive or negative angle in radians (it does not have
            to be in the interval [-2*pi; +2*pi], modulo 2*pi will be realized
            automatically).
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the rotated 3-channel image. It
            has the shape target_height x target_width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.rotate(input_plh, angle_rad)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def resize_image(data_path_name,
                 data_file_name, 
                 result_path_name,
                 result_file_name,
                 target_height,
                 target_width):
    r"""Resizes the image to a given size.
    
    The image will be scaled to a given height (target_height) and a given
    width (target_width). The scaled image will have the dimension
    target_height x target_width. The values of the pixels in the resized image
    are determinded by a bilinear interpolation from the original image's gray
    values.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be resized.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the resized image.
        :result_file_name (*string*)\::
            The name of the resized image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :target_height (*int*)\::   
            The desired height in pixels after resizing.
        :target_width (*int*)\::
            The desired width in pixels after resizing.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.resize_images(input_plh,
                                            [target_height, target_width])
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
    imsave(str(result_path_name) + '/' + str(result_file_name), res)
    

def resize_image_array(input_array,
                       target_height,
                       target_width):
    r"""Resizes the image to a given size.
    
    The image will be scaled to a given height (target_height) and a given
    width (target_width). The scaled image will have the dimension
    target_height x target_width. The values of the pixels in the resized image
    are determinded by a bilinear interpolation from the original image's gray
    values.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be
            resized. It has the shape height x width x 3.
        :target_height (*int*)\::   
            The desired height in pixels after resizing.
        :target_width (*int*)\::
            The desired width in pixels after resizing.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the resized 3-channel image. It
            has the shape target_height x target_width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.resize_images(input_plh,
                                            [target_height, target_width])
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})  
    return output_array


def projective_image_transformation(data_path_name,
                                    data_file_name, 
                                    result_path_name,
                                    result_file_name,
                                    trafo_matrix):
    r"""Applies a projective transformation to the image.
    
    The projective transformation takes the transformation parameters
    a0, a1, a2, b0, b1, b2, c0, c1 and transforms each input pixel (x, y) given
    in the image coordinate system to an output pixel (x', y'). The
    transformation equation is
    
        (x', y') = ((a0 x + a1 y + a2) / k, (b0 x + b1 y + b2) / k)
        
        k        = c0 x + c1 y + 1
    
    Due to translations, rotations, shears or scaling, the result image may is
    not covered entirely by pixel values from the original image. The values
    for pixels for which no information is available in the original image will
    be set to (0, 0, 0) (black).
    
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be transformed.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the transformed image.
        :result_file_name (*string*)\::
            The name of the transformed image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :trafo_matrix (*array*)\::
            Contains the transformation parameters as *floats* in the form
            [a0, a1, a2, b0, b1, b2, c0, c1].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.transform(input_plh,
                                                   trafo_matrix)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img}) 
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def projective_image_transformation_array(input_array,
                                          trafo_matrix):
    r"""Applies a projective transformation to the image.
    
    The projective transformation takes the transformation parameters
    a0, a1, a2, b0, b1, b2, c0, c1 and transforms each input pixel (x, y) given
    in the image coordinate system to an output pixel (x', y'). The
    transformation equation is
    
        (x', y') = ((a0 x + a1 y + a2) / k, (b0 x + b1 y + b2) / k)
        
        k        = c0 x + c1 y + 1
    
    Due to translations, rotations, shears or scaling, the result image may is
    not covered entirely by pixel values from the original image. The values
    for pixels for which no information is available in the original image will
    be set to (0, 0, 0) (black).
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be transformed.
            It has the shape height x width x 3.
        :trafo_matrix (*array*)\::
            Contains the transformation parameters as *floats* in the form
            [a0, a1, a2, b0, b1, b2, c0, c1].
    
    :Returns\::
        :output_array (*array*)\::
            It's a numpy.ndarray containing the transformed 3-channel image. It
            has the shape height x width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.contrib.image.transform(input_plh,
                                                   trafo_matrix)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})   
    return output_array
    
    
def rotate_image_90_counter_clockwise(data_path_name,
                               data_file_name, 
                               result_path_name,
                               result_file_name,
                               n_times):
    r"""Rotates the image counter clockwise by integer multiples of 90°.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be rotated.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the rotated image.
        :result_file_name (*string*)\::
            The name of the rotated image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :n_times (*int*)\::
            The number of the desired 90° rotations. The amount of rotation
            will be n_times*90°. The value of n_times can be an arbitrary
            integer.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.rot90(input_plh, k=n_times)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
   
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def rotate_image_90_counter_clockwise_array(input_array,
                                     n_times):
    r"""Rotates the image counter clockwise by integer multiples of 90°.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be rotated.
            It has the shape height x width x 3.
        :n_times (*int*)\::
            The number of the desired 90° rotations. The amount of rotation
            will be n_times*90°. The value of n_times can be an arbitrary
            integer.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the rotated 3-channel image. It
            has the shape height x width x 3 for an even number of n_times and
            width x height x 3 for an odd number of n_times.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.rot90(input_plh, k=n_times)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def flip_image_left_right(data_path_name,
                          data_file_name, 
                          result_path_name,
                          result_file_name):
    r"""Flips the image horizontally.
    
    The given image will be flipped horizontally along its vertical centre
    line.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be flipped.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the flipped image.
        :result_file_name (*string*)\::
            The name of the flipped image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.flip_left_right(input_plh)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)
    

def flip_image_left_right_array(input_array):
    r"""Flips the image horizontally.
    
    The given image will be flipped horizontally along its vertical centre
    line.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be flipped.
            It has the shape height x width x 3.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the flipped 3-channel image.
            It has the shape height x width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.flip_left_right(input_plh)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def flip_image_up_down(data_path_name,
                       data_file_name, 
                       result_path_name,
                       result_file_name):
    r"""Flips the image vertically.
    
    The given image will be flipped vertically along its horizontal centre
    line.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be flipped.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the flipped image.
        :result_file_name (*string*)\::
            The name of the flipped image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.flip_up_down(input_plh)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)
    

def flip_image_up_down_array(input_array):
    r"""Flips the image vertically.
    
    The given image will be flipped vertically along its horizontal centre
    line.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be flipped.
            It has the shape height x width x 3.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the flipped 3-channel image.
            It has the shape height x width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.flip_up_down(input_plh)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def crop_image_symmetrically(data_path_name,
                             data_file_name, 
                             result_path_name,
                             result_file_name,
                             fraction):
    r"""Crops a bounding box centered on the image.
    
    The the cropped image is an image that is cut out of the original image
    and it has the dimensions according to the given factor. The image height
    will be cropped to (fraction * height) and the image width will be cropped
    to (fraction * width). The image is cropped so that the centre of the
    bounding box is in the centre of the original image. If fraction = 0.5,
    the resulting image has half of the height and half of the width of the
    original image.
  
    Thus, the bounding box has the coordinates:
        
        LUC = ((1-fraction)*height/2, (1-fraction)*width/2)
        
        RLC = (height/2 + fraction*height/2, width/2 + fraction*width/2)
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be cropped.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the cropped image.
        :result_file_name (*string*)\::
            The name of the cropped image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
            It has the shape (fraction * height) x (fraction * width) x 3.
        :fraction (*float*)\::
            The fraction of the original image size to which the image shall be
            cropped. The value has to be in the interval (0, 1].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    if fraction<=0 or fraction>=1:
        print('The fraction has to be in the interval (0,1).')
        return -1
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.central_crop(input_plh, fraction)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def crop_image_symmetrically_array(input_array,
                                   fraction):
    r"""Crops a bounding box centered on the image.
    
    The the cropped image is an image that is cut out of the original image
    and it has the dimensions according to the given factor. The image height
    will be cropped to (fraction * height) and the image width will be cropped
    to (fraction * width). The image is cropped so that the centre of the
    bounding box is in the centre of the original image. If fraction = 0.5,
    the resulting image has half of the height and half of the width of the
    original image.
    
    Thus, the bounding box has the coordinates:
        
        LUC = ((1-fraction)*height/2, (1-fraction)*width/2)
        
        RLC = (height/2 + fraction*height/2, width/2 + fraction*width/2)
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be cropped.
            It has the shape height x width x 3.
        :fraction (*float*)\::
            The fraction of the original image size to which the image shall be
            cropped. The value has to be in the interval (0, 1].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the cropped 3-channel image.
            It has the shape (fraction * height) x (fraction * width) x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.central_crop(input_plh, fraction)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def crop_and_resize_image(data_path_name,
                          data_file_name, 
                          result_path_name,
                          result_file_name,
                          upper_row, left_col,
                          lower_row, right_col,
                          target_height,
                          target_width):
    r"""Crops and resizes an image.
    
    The image first will be cropped to the bounding box with the upper left
    corner at (upper_row, left_col) and lower right corner (lower_row,
    right_col). "To crop" means that the image content inside the bounding box
    is cut out. The row and column indices of the bounding box have to be given
    as a fraction of the total number of rows or columns respectively.
    
    If the upper left corner is given as (0.1, 0.1) and the lower right
    corner as (0.5, 0.5) and the original image has the dimensions 100 x 200 
    pixels, the bounding box will have the upper left corner at (10, 20) and
    the lower right corner at (50, 100). The cropped image corresponds to the
    image that is cutted inside the bounding box.
    
    The pixel values of the result image are obtained by scaling the cropped
    image, whereas the gray values result from a bilinear intrpolation of the
    cropped image's gray values. The final image has the dimension
    target_height x target_width.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be cropped and resized.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the cropped and resized image.
        :result_file_name (*string*)\::
            The name of the cropped and resized image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :upper_row (*float*)\::
            Vertical coordinate of the upper left corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of rows of the
            original image. The value has to be in the interval [0, 1) and
            needs to be smaller than lower_row.
        :left_col (*float*)\::
            Horizontal coordinate of the upper left corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of columns of
            the original image. The value has to be in the interval [0, 1) and
            needs to be smaller than right_col.
        :lower_row (*float*)\::
            Vertical coordinate of the lower right corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of rows of the
            original image. The value has to be in the interval [0, 1) and
            needs to be larger than upper_row.
        :right_col (*float*)\::
            Horizontal coordinate of the lower right corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of columns of
            the original image. The value has to be in the interval [0, 1) and
            needs to be larger than left_col.
        :target_height (*int*)\::
            The height to which the cut image in the bounding box shall be
            scaled. It defines the final height in pixels.
        :target_width (*int*)\::
            The width to which the cut image in the bounding box shall be
            scaled. It defines the final width in pixels.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    if upper_row<0 or left_col<0:
        print('Upper left corner of the bounding box is out of the image!')
        return -1
    if upper_row>lower_row or left_col>right_col:
        print('The indice values for the right lower bounding box corner have',
              'to be larger than those for the left upper corner!')
        return -1
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    img_4D = np.expand_dims(img, axis=0)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [1, None, None, 3])
        result_plh = tf.image.crop_and_resize(input_plh,
                                              [[upper_row, left_col, 
                                               lower_row, right_col]], [0],
                                              [target_height, target_width])
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img_4D})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), np.squeeze(res,
           axis = 0))


def crop_and_resize_image_array(input_array,
                                upper_row, left_col,
                                lower_row, right_col,
                                target_height,
                                target_width):
    r"""Crops and resizes an image.
    
    The image first will be cropped to the bounding box with the upper left
    corner at (upper_row, left_col) and lower right corner (lower_row,
    right_col). "To crop" means that the image content inside the bounding box
    is cut out. The row and column indices of the bounding box have to be given
    as a fraction of the total number of rows or columns respectively.
    
    If the upper left corner is given as (0.1, 0.1) and the lower right
    corner as (0.5, 0.5) and the original image has the dimensions 100 x 200 
    pixels, the bounding box will have the upper left corner at (10, 20) and
    the lower right corner at (50, 100). The cropped image corresponds to the
    image that is cutted inside the bounding box.
    
    The pixel values of the result image are obtained by scaling the cropped
    image, whereas the gray values result from a bilinear intrpolation of the
    cropped image's gray values. The final image has the dimension
    target_height x target_width.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be cropped and
            resized. It has the shape height x width x 3.
        :upper_row (*float*)\::
            Vertical coordinate of the upper left corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of rows of the
            original image. The value has to be in the interval [0, 1) and
            needs to be smaller than lower_row.
        :left_col (*float*)\::
            Horizontal coordinate of the upper left corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of columns of
            the original image. The value has to be in the interval [0, 1) and
            needs to be smaller than right_col.
        :lower_row (*float*)\::
            Vertical coordinate of the lower right corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of rows of the
            original image. The value has to be in the interval [0, 1) and
            needs to be larger than upper_row.
        :right_col (*float*)\::
            Horizontal coordinate of the lower right corner of the bounding box
            to be cut out of the original image. It is a fraction defining the
            bounding box coordinate relative to the total number of columns of
            the original image. The value has to be in the interval [0, 1) and
            needs to be larger than left_col.
        :target_height (*int*)\::
            The height to which the cut image in the bounding box shall be
            scaled. It defines the final height in pixels.
        :target_width (*int*)\::
            The width to which the cut image in the bounding box shall be
            scaled. It defines the final width in pixels.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the cropped and resized
            3-channel image. It has the shape target_height x target_width x 3.
    """
    img_4D = np.expand_dims(input_array, axis=0)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [1, None, None, 3])
        result_plh = tf.image.crop_and_resize(input_plh,
                                              [[upper_row, left_col, 
                                               lower_row, right_col]], [0],
                                              [target_height, target_width])
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: img_4D})
    return np.squeeze(output_array, axis = 0)
    

def zero_padding_until_given_size(data_path_name,
                                  data_file_name, 
                                  result_path_name,
                                  result_file_name,
                                  zero_rows_top,
                                  zero_cols_left,
                                  target_height,
                                  target_width):
    r"""Applies zero padding.
    
    A the number of desired zero rows will be added at the top of the image
    (zero_rows_top) and a number of desired zero columns will be added on the
    left of the image (zero_cols_left). Afterwards, the resulting image will be
    zero padded at the bottom and on the right until the desired target size
    (target_height x target_width) is reached.
    
    If the original image has the height = 100 and width = 200 and the input
    parameters are zero_rows_top = 10, zero_cols_left = 50, target_height = 150
    and target_width = 300, the function will add 10 zero rows at the top and
    50 zero columns at the right. Afterwards, 40 (=150-100-10) zero rows are
    added at the bottom and 50 (=300-200-50) zero columns are added on the
    right.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be zero padded.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name:
            The absolute or relative path to the folder, which shall contain
            the zero padded image. Has to be a string.
        :result_file_name:
            The name of the zero padded image. Has to be a string.
        :zero_rows_top (*int*)\::
            The number of zero rows to add at the top of the image. The value
            has to be larger than or equal to zero.
        :zero_cols_left (*int*)\::
            The number of zero columns to add on the left of the image. The
            value has to be larger than or equal to zero.
        :target_height (*int*)\::
            The target height in pixels, which will be reached by adding
            "target_height - original height - zero_rows_top" zero
            rows at the bottom. The value has to be larger than
            "original height + zero_rows_top"!
        :target_width (*int*)\::
            The target width in pixels, which will be reached by adding
            "target_width - original width - zero_cols_left" zero
            columns on the right. The value has to be larger than
            "original width + zero_cols_left"!
    
    :Returns\::
        No returns.
        The output image will be saved automatically in the given path.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.pad_to_bounding_box(input_plh, 
                                                  zero_rows_top, zero_cols_left,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def zero_padding_until_given_size_array(input_array,
                                        zero_rows_top,
                                        zero_cols_left,
                                        target_height,
                                        target_width):
    r"""Applies zero padding.
    
    A the number of desired zero rows will be added at the top of the image
    (zero_rows_top) and a number of desired zero columns will be added on the
    left of the image (zero_cols_left). Afterwards, the resulting image will be
    zero padded at the bottom and on the right until the desired target size
    (target_height x target_width) is reached.
    
    If the original image has the height = 100 and width = 200 and the input
    parameters are zero_rows_top = 10, zero_cols_left = 50, target_height = 150
    and target_width = 300, the function will add 10 zero rows at the top and
    50 zero columns at the right. Afterwards, 40 (=150-100-10) zero rows are
    added at the bottom and 50 (=300-200-50) zero columns are added on the
    right.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be zero padded.
            It has the shape height x width x 3.
        :zero_rows_top (*int*)\::
            The number of zero rows to add at the top of the image. The value
            has to be larger than or equal to zero.
        :zero_cols_left (*int*)\::
            The number of zero columns to add on the left of the image. The
            value has to be larger than or equal to zero.
        :target_height (*int*)\::
            The target height in pixels, which will be reached by adding
            "target_height - original height - zero_rows_top" zero
            rows at the bottom. The value has to be larger than
            "original height + zero_rows_top"!
        :target_width (*int*)\::
            The target width in pixels, which will be reached by adding
            "target_width - original width - zero_cols_left" zero
            columns on the right. The value has to be larger than
            "original width + zero_cols_left"!
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the zero padded 3-channel image.
            It has the shape target_height x target_width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.pad_to_bounding_box(input_plh, 
                                                  zero_rows_top, zero_cols_left,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array
    

def size_dependent_crop_or_pad(data_path_name,
                               data_file_name,
                               result_path_name,
                               result_file_name,
                               target_height,
                               target_width):
    r"""Crops or pads the image depending on the target size.
    
    "To crop" means that the image content inside a bounding box is cut out and
    "to pad" means that rows and columns of pixels with black gray values are
    appended around the image. Which of these functionalities is applied to the
    input image depends on the chosen target size in relation to the original
    image size.
    
    The input image has the size height x width x 3. The result image has the
    size target_height x target_width x 3. The center point of the result image
    is equal to the centre point of the original image and thus, the target
    image can be intepreted as a bounding box inside or around the original
    image.
    
    :if (target_height > height)\::        
        Pad the original image symmetrically along the vertical image dimension
        until the target_height is reached.
    :else if (target_height < height)\::       
        Crop the original image symmetrically along the vertical image
        dimension to the target_height.
    :else\::
        The vertical image dimension is unchanged.
        
    :if (target_width > width)\::        
        Pad the original image symmetrically along the horizontal image
        dimension until the target_width is reached.
    :else if (target_width < width)\::       
        Crop the original image symmetrically along the horizontal image
        dimension to the target_width.
    :else\::
        The horizontal image dimension is unchanged.
    
    Both image dimensions are handled independently so that one target
    dimension can be larger than the original dimension and the other target
    dimension can be smaller than the original dimension.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be cropped or zero
            padded. The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the cropped or padded image.
        :result_file_name (*string*)\::
            The name of the cropped or padded image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :target_height (*int*)\::
            The desired height of the result image in pixels.
        :target_width (*int*)\::
            The desired width of the result image in pixels.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.resize_image_with_crop_or_pad(input_plh,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)
    

def size_dependent_crop_or_pad_array(input_array,
                                     target_height,
                                     target_width):
    r"""Crops or pads the image depending on the target size.
    
    "To crop" means that the image content inside a bounding box is cut out and
    "to pad" means that rows and columns of pixels with black gray values are
    appended around the image. Which of these functionalities is applied to the
    input image depends on the chosen target size in relation to the original
    image size.
    
    The input image has the size height x width x 3. The result image has the
    size target_height x target_width x 3. The center point of the result image
    is equal to the centre point of the original image and thus, the target
    image can be intepreted as a bounding box inside or around the original
    image.
    
    :if (target_height > height)\::        
        Pad the original image symmetrically along the vertical image dimension
        until the target_height is reached.
    :else if (target_height < height)\::       
        Crop the original image symmetrically along the vertical image
        dimension to the target_height.
    :else\::
        The vertical image dimension is unchanged.
        
    :if (target_width > width)\::        
        Pad the original image symmetrically along the horizontal image
        dimension until the target_width is reached.
    :else if (target_width < width)\::       
        Crop the original image symmetrically along the horizontal image
        dimension to the target_width.
    :else\::
        The horizontal image dimension is unchanged.
    
    Both image dimensions are handled independently so that one target
    dimension can be larger than the original dimension and the other target
    dimension can be smaller than the original dimension.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be cropped or
            padded. It has the shape height x width x 3.
        :target_height (*int*)\::
            The desired height of the result image in pixels.
        :target_width (*int*)\::
            The desired width of the result image in pixels.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the cropped or padded
            3-channel image. It has the shape target_height x target_width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.resize_image_with_crop_or_pad(input_plh,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})  
    return output_array


def crop_image_to_boundingbox(data_path_name,
                              data_file_name, 
                              result_path_name,
                              result_file_name,
                              offset_row,
                              offset_col,
                              target_height,
                              target_width):
    r"""Crops the image to a bounding box.
    
    The image will be cropped to a bounding box given by its upper left corner
    at the original image's pixel coordinates (offset_row, offset_col). The
    bounding box has the size "target_height x target_width". Thus, the
    bounding box has the coordinates:
        
        LUC = (offset_row, offset_col)
        
        RLC = (offset_row + target_height-1, offset_col + target_width-1)
        
    "To crop" means that the image content inside the bounding box is cut out
    and stored in a separate file.
    
    Be careful that "offset_row + target_height - 1" is not larger than the
    original image's height and that "offset_col + target_width - 1" is not
    larger than the original image's width.
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image that shall be cropped.
            The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the cropped image.
        :result_file_name (*string*)\::
            The name of the cropped image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :offset_row (*int*)\::
            The vertical offset of the bounding box in [pixel]. 
        :offset_col (*int*)\::
            The horizontal offset of the bounding box in [pixel].
        :target_height (*int*)\::
            The desired height of the bounding box in [pixel].
        :target_width (*int*)\::
            The desired width of the bounding box in [pixel].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    if (offset_row + target_height-1 > img.shape[0] or
        offset_col + target_width-1 > img.shape[1]):
        print('The bounding box is (partly) out of the image!')
        return -1
    
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.crop_to_bounding_box(input_plh, 
                                                  offset_row, offset_col,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), res)


def crop_image_to_boundingbox_array(input_array,
                                    offset_row,
                                    offset_col,
                                    target_height,
                                    target_width):
    r"""Crops the image to a bounding box.
    
    The image will be cropped to a bounding box given by its upper left corner
    at the original image's pixel coordinates (offset_row, offset_col). The
    bounding box has the size "target_height x target_width". Thus, the
    bounding box has the coordinates:
        
        LUC = (offset_row, offset_col)
        
        RLC = (offset_row + target_height-1, offset_col + target_width-1)
        
    "To crop" means that the image content inside the bounding box is cut out
    and stored in a separate array that is returned.
    
    Be careful that "offset_row + target_height - 1" is not larger than the
    original image's height and that "offset_col + target_width - 1" is not
    larger than the original image's width.
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, that is to be cropped.
            It has the shape height x width x 3.
        :offset_row (*int*)\::
            The vertical offset of the bounding box in [pixel]. 
        :offset_col (*int*)\::
            The horizontal offset of the bounding box in [pixel].
        :target_height (*int*)\::
            The desired height of the bounding box in [pixel].
        :target_width (*int*)\::
            The desired width of the bounding box in [pixel].
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the cropped 3-channel image.
            It has the shape target_height x target_width x 3.
    """
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [None, None, 3])
        result_plh = tf.image.crop_to_bounding_box(input_plh, 
                                                  offset_row, offset_col,
                                                  target_height, target_width)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: input_array})
    return output_array


def extract_glipmse_from_image(data_path_name,
                               data_file_name, 
                               result_path_name,
                               result_file_name,
                               glimpse_height,
                               glimpse_width,
                               glimpse_offset_row,
                               glimpse_offset_col):
    r"""Extracts a glimpse out of the image.
    
    A glimpse, i.e. an image region, of the image will be extracted. The
    differnece to cropping is that the extracted region is allowed to cross the
    image boundary. If the glimpse crosses the image boundary, the pixels
    outside the original image will be filled with noise generated using a
    uniform distribution or a Gaussian distribution. Be careful that the
    glimpse is not entirely out of the original image.
    
    The centre of the glimpse is (glimpse_offset_row, glimpse_offset_col) in
    the coordinate system of the original image and the glimpse will have the
    size "glimpse_height x glimpse_width". Thus, the glimpse has the
    coordinates:
        
        LUC = (glimpse_offset_row - glimpse_height/2, glimpse_offset_col - glimpse_width/2)
        
        RLC = (glimpse_offset_row + glimpse_height/2 - 1, glimpse_offset_col + glimpse_width/2 - 1)
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the original image, from which the glimpse shall be
            extracted. The image has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the extracted glimpse.
        :result_file_name (*string*)\::
            The name of the glimpse image. The result image is a 
            3-channel image (RGB if the input image is an RGB image).
        :glimpse_height (*int*)\::
            The height of the glimpse in pixels.
        :glimpse_width (*int*)\::
            The width of the glimpse in pixels.
        :glimpse_offset_row (*int*)\::
            The vertical offset for the centre of the glimpse.
        :glimpse_offset_col (*int*)\::
            The horizontal offset for the centre of the glimpse.
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    img = imageio.imread(os.path.join(data_path_name, 
                                      data_file_name)).astype(np.float32)
    img_4D = np.expand_dims(img, axis=0)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [1, None, None, 3])
        result_plh = tf.image.extract_glimpse(input_plh,
                                              [glimpse_height, glimpse_width],
                                              [[glimpse_offset_row, glimpse_offset_col]],
                                              centered=False,
                                              normalized=False)
    with tf.Session(graph = g) as sess:
        res = sess.run(result_plh, feed_dict = {input_plh: img_4D})
        
    imsave(str(result_path_name) + '/' + str(result_file_name), np.squeeze(res,
           axis = 0))


def extract_glipmse_from_image_array(input_array,
                                     glimpse_height,
                                     glimpse_width,
                                     glimpse_offset_row,
                                     glimpse_offset_col):
    r"""Extracts a glimpse out of the image.
    
    A glimpse, i.e. an image region, of the image will be extracted. The
    differnece to cropping is that the extracted region is allowed to cross the
    image boundary. If the glimpse crosses the image boundary, the pixels
    outside the original image will be filled with noise generated using a
    uniform distribution or a Gaussian distribution. Be careful that the
    glimpse is not entirely out of the original image.
    
    The centre of the glimpse is (glimpse_offset_row, glimpse_offset_col) in
    the coordinate system of the original image and the glimpse will have the
    size "glimpse_height x glimpse_width". Thus, the glimpse has the
    coordinates:
        
        LUC = (glimpse_offset_row - glimpse_height/2,
               glimpse_offset_col - glimpse_width/2)
        
        RLC = (glimpse_offset_row + glimpse_height/2 - 1,
               glimpse_offset_col + glimpse_width/2 - 1)
    
    :Arguments\::
        :input_array (*array*)\::
            The array containing the original image, from which the glimpse
            shall be extracted. It has the shape height x width x 3.
        :glimpse_height (*int*)\::
            The height of the glimpse in pixels.
        :glimpse_width (*int*)\::
            The width of the glimpse in pixels.
        :glimpse_offset_row (*int*)\::
            The vertical offset for the centre of the glimpse.
        :glimpse_offset_col (*int*)\::
            The horizontal offset for the centre of the glimpse.
    
    :Returns\::
        :output_array (*array*)\::
            This is a numpy.ndarray containing the 3-channel glimpse image.
            It has the shape glimpse_height x glimpse_width x 3.
    """
    img_4D = np.expand_dims(input_array, axis=0)
    g = tf.Graph()
    with g.as_default():
        input_plh  = tf.placeholder(tf.float32, [1, None, None, 3])
        result_plh = tf.image.extract_glimpse(input_plh,
                                              [glimpse_height, glimpse_width],
                                              [[glimpse_offset_row, glimpse_offset_col]],
                                              centered=False,
                                              normalized=False)
    with tf.Session(graph = g) as sess:
        output_array = sess.run(result_plh, feed_dict = {input_plh: img_4D})
    return np.squeeze(output_array, axis = 0)
    
    