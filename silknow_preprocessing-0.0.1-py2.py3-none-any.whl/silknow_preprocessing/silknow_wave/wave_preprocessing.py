
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cv2
import numpy as np
import random as rng


def posterize_image(data_path_name,
                    data_file_name,
                    n_clusters, 
                    result_path_name,
                    result_file_name):
#    
    r"""Posterizes an image based on a given number.
    
    Image posterization or color quantization is the process of reducing number of colors in an image. 
    In this function, we use k-means clustering for color quantization.
    The function works as follows:
        - There are 3 features, say, R,G,B, so we need to reshape the image to an array of Mx3 size (M is number of pixels in image).
        - After the clustering, we apply centroid values (it is also R,G,B) to all pixels, such that resulting image will have specified number of colors.
        - And again, we need to reshape it back to the shape of original image.
    
    **Attention**\: The number of clusters should be equal or greater than 2.
    If the number of clusters is equal to 1, then an image with a plane colour will be generated.    
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :n_clusters (*integer*)\::
            The number of clusters.

            Example: 2.
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """

    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    Z = img.reshape((-1,3))

    # convert to np.float32
    Z = np.float32(Z)

    # define criteria, number of clusters(K) and apply kmeans()
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    #n_clusters = 15
    ret,label,center=cv2.kmeans(Z,n_clusters,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)

    # Now convert back into uint8, and make original image
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((img.shape))

   
    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), res2)
    


def get_background_from_posterized_image(data_path_name,
                    data_file_name,
                    x_value,
                    y_value, 
                    result_path_name,
                    result_file_name):
#    
    r"""Generates a mask image with the background.
    
    This function returns an image with back/white information.
    The white (255,255,255) is the background.
    As input, it needs an (x,y) value.
    The (R,G,B) values of the original image corresponding to the given (x,y) pixel coordintes,
    is considered as the background color.
    Then, the function consideres all the pixels in the original image having that (R,G,B) value
    as being part of the background, and generates an image with (R=255,G=255,B=255)
    where the background is, and with (R=0,G=0,B=0) otherwise.
    
    **Attention**\: The imput image should be a posterized image.
    The function posterize_image can be used for image posterization.
    Do not use compressed images (e.g. jpg), as you won't get a good result.
    Use instead tiff images.    
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :x_value (*integer*)\::
            The 'x' coordinte of a pixel belonging to the background.

            Example: 200.
        :y_value (*integer*)\::
            The corresponding 'y' coordinte of the same pixel (as for the x_value) belonging to the background.

            Example: 200.        
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """

    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    # NOT YET IMPLEMENTED
    
    # grab the image dimensions
    img_height = img.shape[0]
    img_width = img.shape[1]

    blue = img[y_value,x_value,0]
    green = img[y_value,x_value,1]
    red = img[y_value,x_value,2]

    blank_image = np.zeros((img_height,img_width,3), np.uint8)


    # loop over the image, pixel by pixel
    for y in range(0, img_height):
        for x in range(0, img_width):
            # threshold the pixel
            if img[y, x, 0] == blue and img[y, x, 1] == green and img[y, x, 2] == red:
                blank_image[y, x, 0] = blank_image[y, x, 1] = blank_image[y, x, 2] = 255 




    # return the thresholded image

    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), blank_image)
    


def threshold_image(data_path_name,
                data_file_name,
                blockSize,
                constSubt, 
                result_path_name,
                result_file_name):
#  
    r"""Applies a Gaussian Adaptive Threshold to an image.
    
    The adaptive threshold function calculates local thresholds.
    As a result, we get different thresholds for different regions of the same image.
    A local threshold gives better results for images with varying illumination.
    The threshold value is the weighted sum of neighbourhood values where weights are a gaussian window.


    **Attention**\: RGB images are converted to greyscale images before applying the threshold.
    The resulting image is a greyscale image.


    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :blockSize (*integer*)\::
            Size of a pixel neighborhood that is used to calculate a threshold value for the pixel: 3, 5, 7, and so on.
            It has to be an odd integer.

            Example: 11
        :constSubt (*integer*)\::
            Constant subtracted from the mean or weighted mean. Normally, it is positive but may be zero or negative as well.

            Example: 2
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    # Load a color image
    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    # convert the image to gray
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # apply a gaussian, local threshold
    thresh = cv2.adaptiveThreshold(gray_image,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,blockSize,constSubt)

    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), thresh)


def find_crosses_image(data_path_name,
            data_file_name,
            crossSize,
            itDilate, 
            result_path_name,
            result_file_name):
#  
    r"""Find crosses in a thresholded image.
    
    This function uses a morphological operator of the form of a cross in order to find crosses in an image.
    This morphological operator is defined as follows in OpenCV:
        Cross-shaped Kernel
        cv2.getStructuringElement(cv2.MORPH_CROSS,(5,5))
        array([[0, 0, 1, 0, 0],
                [0, 0, 1, 0, 0],
                [1, 1, 1, 1, 1],
                [0, 0, 1, 0, 0],
                [0, 0, 1, 0, 0]], dtype=uint8)


    **Attention**\: You need a thresholded image of a technical drawing as an input.
    You can get the thresholded image by applying the function threshold_image.

    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :crossSize (*integer*)\::
            The size of the cross.

            Example: 20.
        :itDilate (*integer*)\::
            A dilate funciton is applied in order to dilate the found crosses.
            itDilate is the number of iterations for dilate.

            Example: 10
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        No returns.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    # Load a greyscale image (thresholded)
    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    crossStructure = cv2.getStructuringElement(cv2.MORPH_CROSS,(crossSize,crossSize))
    cross = cv2.dilate(img,crossStructure,itDilate)
    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), cross)


def get_rows_cols_from_point_grid(data_path_name,
                                    data_file_name,
                                    xjump,
                                    yjump, 
                                    result_path_name,
                                    result_file_name):
#  
    r"""Find rows and cols in a point grid image.
    
    This function finds the number of rows and cols in an image that is composed of a point grid, such as:
        .  .  .  .  .  .  .  .
        .  .  .  .  .  .  .  .
        .  .  .  .  .  .  .  .    
        .  .  .  .  .  .  .  .    
        .  .  .  .  .  .  .  .
        .  .  .  .  .  .  .  .
        .  .  .  .  .  .  .  .

    To do that, it first calculates the (x,y) coordinates of each point grid.
    This is achieved by considering them as 'blobs', as these kind of objects
    do have the desired coordinates.

    **Attention**\: You need a point grid image of a technical drawing as an input.
    You can get the point grid image by applying the function find_crosses_image.
    Use an image corredted from perspective, as the algorithm assumes that the
    point grid is aligned witht the vertical and horizontal axes.
    Use small values for xjump yjump if the point grid is roughly aligned
    with the vertical and horizontal axis

    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :xjump (*integer*)\::
            The min jump in pixels between two consecutive cols

            Example: 3
        :yjump (*integer*)\::
            The min jump in pixels between two consecutive rows

            Example: 5    
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        Returns the number of cols and rows.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """
    # Load a greyscale image (thresholded)
    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    # find blobs in picture in order to compute the xy coordiantes of each cross

    # Setup SimpleBlobDetector parameters.
    params = cv2.SimpleBlobDetector_Params()
    
    # Change thresholds
    params.minThreshold = 10
    params.maxThreshold = 200
    
    # Filter by Area.
    params.filterByArea = True
    params.minArea = 2
    
    # Filter by Circularity
    params.filterByCircularity = False
    params.minCircularity = 0.1
    
    # Filter by Convexity
    params.filterByConvexity = False
    params.minConvexity = 0.87
    
    # Filter by Inertia
    params.filterByInertia = False
    params.minInertiaRatio = 0.01
    
    # Create a detector with the parameters
    ver = (cv2.__version__).split('.')
    if int(ver[0]) < 3 :
        detector = cv2.SimpleBlobDetector(params)
    else : 
        detector = cv2.SimpleBlobDetector_create(params)
    
    # Detect blobs.
    keypoints = detector.detect(img)
    
    # Draw detected blobs as red circles.
    # cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS ensures the size of the circle corresponds to the size of blob
    im_with_keypoints = cv2.drawKeypoints(img, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    
    # write an image with the keypoints 
    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), im_with_keypoints)

    # COUNT THE NUMBER OF ROWS
    # Per default, keypoints are ordered according to the "y" values (from greater to lower)
    # for example:
        # x = 99.5; y = 46.5
        # x = 84.5; y = 45.5
        # x = 68.5; y = 45.5
        # x = 52.5; y = 45.5
        # x = 36.5; y = 45.5
        # x = 21.0; y = 45.5
        # x = 1655.0; y = 35.0 (jump!!!)
        # x = 1873.0; y = 34.5
        # x = 1857.5; y = 34.5
    # we look for the jumps in "y", so we can discern the different aligned blobs (blobs inside rows) to count the rows
    # attention: if lines are not parallel/perpendicular, the "x/y" values of a line will not have a constant value,
    # so we need to look for jumps that a greater that a certain value "yjump"
    first = True
    anterior = 0
    ysaltos = []
    count = 0
    #yjump = 5
    lista_x = []

    for keypoint in keypoints:
        # x = keypoint.pt[0]
        y = keypoint.pt[1]
        # s = keypoint.size
        # print("x = " + repr(x) + "; y = " + repr(y))
        # print(s)
        lista_x.append(keypoint.pt[0])
    
        if first:
            ysalto = 0
            first = False
        else:
            ysalto = anterior - y

        if ysalto > yjump:
            count = count + 1

        ysaltos.append(ysalto)

        anterior = y
        #print (ysalto) 


    #print ("number of ysaltos: " + repr(count) ) # the number of rows has to be = count + 1
    print ("number of rows: " + repr(count+1) ) # the number of rows has to be = count + 1
    n_rows = count+1

    # COUNT THE NUMBER OF COLUMNS  
    # In order to proceed as in the rows, we need to first order the data according to the "x" values
    
    sorted_x_keypoints = sorted(lista_x, reverse=True)
     
    first = True
    anterior = 0
    xsaltos = []
    count = 0
    #xjump = 3
    for sorted_x_keypoint in sorted_x_keypoints:
        x = sorted_x_keypoint
        #print("x = " + repr(x))
        
        if first:
            xsalto = 0
            first = False
        else:
            xsalto = anterior - x

        if xsalto > xjump:
            count = count + 1

        xsaltos.append(xsalto)

        anterior = x
        #print (xsalto) 

    print ("number of cols: " + repr(count+1) ) # the number of cols has to be = count + 1
    n_cols = count+1

    return n_cols, n_rows


def get_countours(data_path_name,
            data_file_name,
            threshold,
            isWhite, 
            result_path_name,
            result_file_name):
#    
    r"""Get the countours of an image.
    
    This function calculates the contours of an image.
    The resulting contours are in vector form.
    An image is generated that draws the contours in RGB values (white or random)
    
    **Attention**\: use a posterized image to get better results.    
    
    :Arguments\::
        :data_path_name (*string*)\::
            The absolute or relative path to the storage location of the
            original image. Relative paths are given with respect to the
            storage location of the script importing this toolbox.
            
            Example (abolute): 'C:\\users\\image_folder_name'
            
            Example (relative): '.\\image_folder_name'
        :data_file_name (*string*)\::
            The name of the input image. The image
            has to be a 3-channel image (for example RGB).
            
            Example: 'my_test_image.jpg'
        :threshold (*integer*)\::
            Threshold value for a Canny detector.

            Example: 100.
        :isWhite (*boolean*)\::
            If this variable is true, all countours will be drawn in white colour in the resulting image;
            otherwise, random colours will be individually applied to contours.

            Example: True.
        :result_path_name (*string*)\::
            The absolute or relative path to the folder that shall contain
            the result image.
        :result_file_name (*string*)\::
            The name of the result image. The result image is a 
            3-channel image (RGB if the input image is an RGB image). The gray
            values of the saved image are scaled to integers in the range
            [0; 255].
    
    :Returns\::
        Returns a list of vectors with the countours.
        The output image will be saved to the given path. The full filename
        will be result_path_name\\result_file_name.
    """

    # Load an image
    img = cv2.imread(str(data_path_name) + '/' + str(data_file_name))

    # Convert image to gray and blur it
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_gray = cv2.blur(img_gray, (3,3))


    # Detect edges using Canny
    canny_output = cv2.Canny(img_gray, threshold, threshold * 2)

    # Find contours
    algo, contours, hierarchy = cv2.findContours(canny_output, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Approximate contours to polygons
    # contours_poly = [None]*len(contours)
    # for i, c in enumerate(contours):
    #     contours_poly[i] = cv2.approxPolyDP(c, 3, True)

    drawing = np.zeros((canny_output.shape[0], canny_output.shape[1], 3), dtype=np.uint8)

    # Draw polygonal contour
    for i in range(len(contours)):
        if isWhite==True:
            color = (255, 255, 255)
        else:
            color = (rng.randint(0,256), rng.randint(0,256), rng.randint(0,256))
        cv2.drawContours(drawing, contours, i, color)
    
    # write an image with the contours 
    cv2.imwrite(str(result_path_name) + '/' + str(result_file_name), drawing)

    return contours



